export default { theme: { extend: {} } };
